package it.mourad.arabiatv;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Rule;import org.junit.Test;import org.junit.runner.RunWith;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.*;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.*;
import static org.hamcrest.Matchers.*;
@RunWith(AndroidJUnit4.class)
public class RadioCastSmokeTest {
    @Rule public ActivityScenarioRule<MainActivity> activity=new ActivityScenarioRule<>(MainActivity.class);
    @Test public void originalRadioScreenAndCastButtonAreReachable() {
        onView(withTagValue(is("open-radio"))).perform(click());
        onView(withHint("Cerca stazione, città o categoria…")).check(matches(isDisplayed()));
        onView(withTagValue(is("radio-cast"))).perform(click());
        onView(withText("Cerca TV sulla rete (DLNA)")).check(matches(isDisplayed()));
    }
    @Test public void samsungOptionsAreReachableFromTvHome() {
        onView(withTagValue(is("cast-tv"))).perform(click());
        onView(withText("Smart View / proietta schermo")).check(matches(isDisplayed()));
    }
}
