package it.mourad.arabiatv;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.widget.TextView;
import androidx.media3.common.Player;
import androidx.media3.ui.PlayerView;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class PlaybackSmokeTest {
    @Test public void aPublicLiveChannelActuallyStartsInTheNativePlayer() throws Exception {
        Context context=InstrumentationRegistry.getInstrumentation().getTargetContext();
        Channel live=null;
        for(Channel channel:CatalogStore.load(context))if(channel.id.equals("france24")&&!channel.stream.isEmpty())live=channel;
        assertNotNull("Verified France 24 public stream must be present for the integration smoke test",live);
        Intent launch=new Intent(context,PlayerActivity.class).putExtra("title",live.name).putExtra("stream",live.stream).putExtra("official",live.official).putExtra("arabic",false);
        AtomicBoolean playing=new AtomicBoolean();AtomicReference<String> status=new AtomicReference<>("");
        try(ActivityScenario<PlayerActivity> scenario=ActivityScenario.launch(launch)) {
            long deadline=SystemClock.elapsedRealtime()+45000;
            while(!playing.get()&&SystemClock.elapsedRealtime()<deadline) {
                scenario.onActivity(activity->{
                    PlayerView view=activity.getWindow().getDecorView().findViewWithTag("player-view");
                    TextView label=activity.getWindow().getDecorView().findViewWithTag("playback-status");
                    if(label!=null)status.set(label.getText().toString());
                    Player player=view==null?null:view.getPlayer();
                    playing.set(player!=null&&player.isPlaying()&&player.getPlaybackState()==Player.STATE_READY&&player.getCurrentPosition()>500);
                });
                if(!playing.get())SystemClock.sleep(500);
            }
            assertTrue("Native HLS playback did not start. UI status: "+status.get(),playing.get());
        }
    }
}
