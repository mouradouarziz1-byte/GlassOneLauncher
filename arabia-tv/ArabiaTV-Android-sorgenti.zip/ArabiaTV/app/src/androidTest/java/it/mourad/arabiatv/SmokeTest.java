package it.mourad.arabiatv;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.*;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.*;
import static org.hamcrest.Matchers.*;
@RunWith(AndroidJUnit4.class)
public class SmokeTest {
    @Rule public ActivityScenarioRule<MainActivity> activity=new ActivityScenarioRule<>(MainActivity.class);
    @Test public void catalogSearchAndEmptyStateWork() {
        onView(withTagValue(is("search"))).perform(replaceText("الجزيرة"),closeSoftKeyboard());
        onView(withText("Al Jazeera")).check(matches(isDisplayed()));
        onView(withTagValue(is("search"))).perform(replaceText("zzzz-no-channel"),closeSoftKeyboard());
        onView(withTagValue(is("empty"))).check(matches(isDisplayed()));
    }
    @Test public void languageAndSettingsCanBeOpened() {
        onView(withTagValue(is("nav-settings"))).perform(click());
        onView(withTagValue(is("import"))).check(matches(isDisplayed()));
        onView(withTagValue(is("language"))).perform(click());
        onView(withTagValue(is("import"))).check(matches(withText(containsString("استيراد"))));
    }
}
