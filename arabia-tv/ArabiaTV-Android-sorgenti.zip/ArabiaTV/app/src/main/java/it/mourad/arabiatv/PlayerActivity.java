package it.mourad.arabiatv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;

@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public final class PlayerActivity extends Activity {
    private ExoPlayer player;
    private PlayerView playerView;
    private ProgressBar progress;
    private TextView status;
    private String stream,official;
    private boolean arabic,playWhenReady=true;
    private int quality=0;
    private boolean landscape;
    private String t(String it,String ar){return arabic?ar:it;}
    private int dp(float value){return Ui.dp(this,value);}
    private Button button(String label) {
        Button view=new Button(this);view.setText(label);view.setAllCaps(false);view.setTextSize(12);view.setTextColor(Ui.ACCENT);
        view.setBackground(Ui.shape(this,Ui.SURFACE,12));view.setMinHeight(dp(48));return view;
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        stream=getIntent().getStringExtra("stream");official=getIntent().getStringExtra("official");arabic=getIntent().getBooleanExtra("arabic",false);
        if(!Channel.isHttps(stream)){finish();return;}
        quality=getSharedPreferences("arabia",MODE_PRIVATE).getInt("quality",0);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Ui.BG);root.setLayoutDirection(arabic?View.LAYOUT_DIRECTION_RTL:View.LAYOUT_DIRECTION_LTR);
        setContentView(root);Ui.insets(this,root);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(12),dp(10),dp(12),dp(10));
        Button back=button("‹");back.setContentDescription(t("Torna ai canali","العودة إلى القنوات"));back.setOnClickListener(view->finish());header.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));
        TextView name=Ui.text(this,getIntent().getStringExtra("title"),19,Ui.TEXT,true);name.setPadding(dp(14),0,dp(8),0);header.addView(name,new LinearLayout.LayoutParams(0,-2,1));root.addView(header);
        FrameLayout frame=new FrameLayout(this);root.addView(frame,new LinearLayout.LayoutParams(-1,0,1));
        playerView=new PlayerView(this);playerView.setTag("player-view");playerView.setShowNextButton(false);playerView.setShowPreviousButton(false);playerView.setKeepContentOnPlayerReset(false);frame.addView(playerView,new FrameLayout.LayoutParams(-1,-1));
        progress=new ProgressBar(this);FrameLayout.LayoutParams progressLayout=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.CENTER);frame.addView(progress,progressLayout);
        status=Ui.text(this,t("Connessione alla diretta…","جارٍ الاتصال بالبث…"),13,Ui.MUTED,false);status.setTag("playback-status");status.setPadding(dp(20),dp(15),dp(20),dp(10));root.addView(status);
        LinearLayout controls=new LinearLayout(this);controls.setPadding(dp(12),0,dp(12),dp(8));
        Button retry=button(t("Riprova","أعد المحاولة"));retry.setOnClickListener(view->{if(player!=null){status.setText(t("Connessione…","جارٍ الاتصال…"));player.prepare();player.play();}});controls.addView(retry,new LinearLayout.LayoutParams(0,dp(48),1));
        Button qualityButton=button(t("Qualità","الجودة"));qualityButton.setOnClickListener(view->chooseQuality());LinearLayout.LayoutParams control=new LinearLayout.LayoutParams(0,dp(48),1);control.setMargins(dp(7),0,dp(7),0);controls.addView(qualityButton,control);
        Button full=button(t("Ruota","تدوير"));full.setOnClickListener(view->{landscape=!landscape;setRequestedOrientation(landscape?ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE:ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);});controls.addView(full,new LinearLayout.LayoutParams(0,dp(48),1));root.addView(controls);
        if(Channel.isHttps(official)) {
            Button source=button(t("↗ Apri la diretta sul sito ufficiale","↗ افتح البث على الموقع الرسمي"));LinearLayout.LayoutParams sourceLayout=new LinearLayout.LayoutParams(-1,dp(48));sourceLayout.setMargins(dp(12),0,dp(12),dp(12));root.addView(source,sourceLayout);
            source.setOnClickListener(view->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(official)));}catch(Exception error){status.setText(t("Nessuna app disponibile per aprire il sito.","لا يوجد تطبيق لفتح الموقع."));}});
        }
    }
    private void initializePlayer() {
        DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory().setUserAgent("ArabiaTV/1.0 (Android)")
            .setConnectTimeoutMs(15000).setReadTimeoutMs(15000).setAllowCrossProtocolRedirects(false);
        player=new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(http)).build();
        player.setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),true);
        playerView.setPlayer(player);applyQuality();
        MediaItem.Builder item=new MediaItem.Builder().setUri(stream);
        if(Uri.parse(stream).getPath()!=null&&Uri.parse(stream).getPath().toLowerCase(java.util.Locale.ROOT).contains(".m3u8"))item.setMimeType(MimeTypes.APPLICATION_M3U8);
        player.setMediaItem(item.build());
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                progress.setVisibility(state==Player.STATE_BUFFERING?View.VISIBLE:View.GONE);
                if(state==Player.STATE_READY)status.setText(player.isCurrentMediaItemLive()?t("● In diretta · qualità adattiva","● مباشر · جودة تلقائية"):t("Riproduzione · qualità adattiva","مشاهدة · جودة تلقائية"));
                else if(state==Player.STATE_BUFFERING)status.setText(t("Caricamento della diretta…","جارٍ تحميل البث…"));
                else if(state==Player.STATE_ENDED)status.setText(t("La trasmissione è terminata.","انتهى البث."));
            }
            @Override public void onIsPlayingChanged(boolean isPlaying) {
                if(isPlaying)getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
            @Override public void onPlayerError(PlaybackException error) {
                progress.setVisibility(View.GONE);
                status.setText(Channel.isHttps(official)?t("Diretta non disponibile. Riprova o apri il sito ufficiale. Il canale potrebbe applicare limiti territoriali.","البث غير متاح. أعد المحاولة أو افتح الموقع الرسمي. قد تطبق القناة قيوداً جغرافية."):t("Diretta non disponibile. Controlla la rete e l’indirizzo nella tua playlist.","البث غير متاح. تحقق من الشبكة وعنوان البث في قائمتك."));
            }
        });
        player.prepare();player.setPlayWhenReady(playWhenReady);
    }
    private void chooseQuality() {
        String[] options={t("Automatica","تلقائية"),t("Risparmio dati · fino a 480p","توفير البيانات · حتى 480p"),t("Fino a 720p","حتى 720p"),t("Fino a 1080p","حتى 1080p")};
        new AlertDialog.Builder(this).setTitle(t("Qualità massima","الحد الأقصى للجودة")).setSingleChoiceItems(options,quality,(dialog,which)->{
            quality=which;getSharedPreferences("arabia",MODE_PRIVATE).edit().putInt("quality",which).apply();applyQuality();dialog.dismiss();
        }).setNegativeButton(t("Chiudi","إغلاق"),null).show();
    }
    private void applyQuality() {
        if(player==null)return;
        int[][] limits={{Integer.MAX_VALUE,Integer.MAX_VALUE,Integer.MAX_VALUE},{854,480,1400000},{1280,720,3500000},{1920,1080,6500000}};
        int[] limit=limits[Math.max(0,Math.min(quality,3))];
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setMaxVideoSize(limit[0],limit[1]).setMaxVideoBitrate(limit[2]).build());
    }
    @Override protected void onStart(){super.onStart();if(Channel.isHttps(stream)&&playerView!=null)initializePlayer();}
    @Override protected void onStop(){if(player!=null){playWhenReady=player.getPlayWhenReady();playerView.setPlayer(null);player.release();player=null;}getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);super.onStop();}
}
