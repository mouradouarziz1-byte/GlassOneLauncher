package it.mourad.arabiatv;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class CatalogStore {
    public static List<Channel> load(Context context) throws Exception {
        List<Channel> channels;
        try(InputStream input=context.getAssets().open("channels.json")) { channels=decode(read(input)); }
        if(context.getFileStreamPath("imports.json").exists()) {
            try(InputStream input=context.openFileInput("imports.json")) { channels.addAll(decode(read(input))); }
        }
        return channels;
    }
    public static void saveImports(Context context,List<Channel> channels) throws Exception {
        JSONArray data=new JSONArray();
        for(Channel channel:channels) {
            JSONObject item=new JSONObject();
            item.put("id",channel.id);item.put("name",channel.name);item.put("arabic",channel.arabic);
            item.put("country",channel.country);item.put("category",channel.category);
            item.put("official",channel.official);item.put("stream",channel.stream);data.put(item);
        }
        try(java.io.OutputStream output=context.openFileOutput("imports.json",Context.MODE_PRIVATE)) {
            output.write(data.toString().getBytes(StandardCharsets.UTF_8));
        }
    }
    private static List<Channel> decode(String text) throws Exception {
        JSONArray items=new JSONArray(text); List<Channel> channels=new ArrayList<>();
        for(int i=0;i<items.length();i++) {
            JSONObject item=items.getJSONObject(i);
            String official=item.optString("official"),stream=item.optString("stream");
            channels.add(new Channel(item.getString("id"),item.getString("name"),item.getString("arabic"),
                item.getString("country"),item.getString("category"),Channel.isHttps(official)?official:"",Channel.isHttps(stream)?stream:""));
        }
        return channels;
    }
    public static String read(InputStream input) throws Exception {
        ByteArrayOutputStream output=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;
        while((count=input.read(buffer))!=-1) {
            if(output.size()+count>PlaylistParser.MAX_BYTES)throw new IllegalArgumentException("File troppo grande");
            output.write(buffer,0,count);
        }
        return output.toString(StandardCharsets.UTF_8.name());
    }
}
