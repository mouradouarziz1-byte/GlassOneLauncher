package it.mourad.arabiatv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public final class MainActivity extends androidx.activity.ComponentActivity {
    private SharedPreferences preferences;
    private boolean arabic;
    private String mode="all",country="ALL",category="ALL",query="";
    private List<Channel> catalog=new ArrayList<>(),visible=new ArrayList<>();
    private Set<String> favorites=new HashSet<>();
    private final List<String> recent=new ArrayList<>();
    private LinearLayout root,body;
    private TextView counter,empty;
    private ChannelAdapter adapter;
    private static final String[][] COUNTRIES={
        {"MA","🇲🇦 Marocco","🇲🇦 المغرب"},{"DZ","🇩🇿 Algeria","🇩🇿 الجزائر"},{"TN","🇹🇳 Tunisia","🇹🇳 تونس"},
        {"LY","🇱🇾 Libia","🇱🇾 ليبيا"},{"MR","🇲🇷 Mauritania","🇲🇷 موريتانيا"},{"EG","🇪🇬 Egitto","🇪🇬 مصر"},
        {"SD","🇸🇩 Sudan","🇸🇩 السودان"},{"SA","🇸🇦 Arabia Saudita","🇸🇦 السعودية"},{"AE","🇦🇪 Emirati Arabi","🇦🇪 الإمارات"},
        {"QA","🇶🇦 Qatar","🇶🇦 قطر"},{"KW","🇰🇼 Kuwait","🇰🇼 الكويت"},{"BH","🇧🇭 Bahrain","🇧🇭 البحرين"},
        {"OM","🇴🇲 Oman","🇴🇲 عُمان"},{"IQ","🇮🇶 Iraq","🇮🇶 العراق"},{"JO","🇯🇴 Giordania","🇯🇴 الأردن"},
        {"LB","🇱🇧 Libano","🇱🇧 لبنان"},{"PS","🇵🇸 Palestina","🇵🇸 فلسطين"},{"SY","🇸🇾 Siria","🇸🇾 سوريا"},
        {"YE","🇾🇪 Yemen","🇾🇪 اليمن"},{"SO","🇸🇴 Somalia","🇸🇴 الصومال"},{"DJ","🇩🇯 Gibuti","🇩🇯 جيبوتي"},
        {"KM","🇰🇲 Comore","🇰🇲 جزر القمر"},{"WORLD","🌐 Internazionali","🌐 دولية"},{"USER","＋ La tua playlist","＋ قائمتك الخاصة"}
    };
    private static final String[][] CATEGORIES={
        {"ALL","Tutti","الكل"},{"DIRECT","In app","داخل التطبيق"},{"News","Notizie","أخبار"},
        {"General","Generali","عامة"},{"Sports","Sport","رياضة"},{"Religion","Religione","دينية"},
        {"Kids","Bambini","أطفال"},{"Documentary","Documentari","وثائقية"},{"Culture","Cultura","ثقافة"}
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        preferences=getSharedPreferences("arabia",MODE_PRIVATE);
        arabic=preferences.getBoolean("arabic",false);
        favorites=new HashSet<>(preferences.getStringSet("favorites",Collections.emptySet()));
        try {
            JSONArray items=new JSONArray(preferences.getString("recent","[]"));
            for(int i=0;i<items.length();i++)recent.add(items.getString(i));
        } catch(Exception ignored) { recent.clear(); }
        if(saved!=null) {
            mode=saved.getString("mode","all");country=saved.getString("country","ALL");
            category=saved.getString("category","ALL");query=saved.getString("query","");
        }
        loadCatalog(); render();
        getOnBackPressedDispatcher().addCallback(this,new androidx.activity.OnBackPressedCallback(true){@Override public void handleOnBackPressed(){handleBack();}});
    }
    private void loadCatalog() {
        try { catalog=CatalogStore.load(this); }
        catch(Exception error) { catalog=new ArrayList<>(); toast(t("Catalogo non disponibile","الكتالوج غير متاح")); }
    }
    private String t(String italian,String ar){return arabic?ar:italian;}
    private int dp(float value){return Ui.dp(this,value);}
    private LinearLayout column() { LinearLayout view=new LinearLayout(this);view.setOrientation(LinearLayout.VERTICAL);return view; }
    private TextView text(String value,int size,int color,boolean bold){return Ui.text(this,value,size,color,bold);}
    private Button button(String label,int color) {
        Button view=new Button(this);view.setText(label);view.setTextColor(color);view.setTextSize(12);
        view.setAllCaps(false);view.setMinHeight(dp(46));view.setMinimumHeight(dp(46));
        view.setPadding(dp(12),dp(4),dp(12),dp(4));view.setBackground(Ui.shape(this,Ui.SURFACE,12));return view;
    }
    private void render() {
        root=column();root.setBackgroundColor(Ui.BG);root.setLayoutDirection(arabic?View.LAYOUT_DIRECTION_RTL:View.LAYOUT_DIRECTION_LTR);
        setContentView(root);Ui.insets(this,root);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(20),dp(12),dp(15),dp(9));
        TextView brand=text("ARABIA TV",23,Ui.TEXT,true);brand.setLetterSpacing(.07f);header.addView(brand,new LinearLayout.LayoutParams(0,dp(48),1));brand.setGravity(Gravity.CENTER_VERTICAL);
        Button language=button(arabic?"Italiano":"العربية",Ui.ACCENT);language.setTag("language");
        language.setOnClickListener(view->{preferences.edit().putBoolean("arabic",!arabic).apply();arabic=!arabic;render();});
        header.addView(language);root.addView(header);
        LinearLayout mediaBar=new LinearLayout(this);mediaBar.setPadding(dp(20),0,dp(20),dp(6));
        Button radio=button(t("Radio Maroc · 22 stazioni","راديو المغرب · 22 محطة"),Ui.ACCENT);radio.setTag("open-radio");radio.setOnClickListener(v->startActivity(new Intent(this,com.mourad.radiomaroc.MainActivity.class)));
        mediaBar.addView(radio,new LinearLayout.LayoutParams(0,dp(46),1));
        Button tv=button(t("Trasmetti su TV","البث على التلفزيون"),Ui.MUTED);tv.setTag("cast-tv");tv.setOnClickListener(v->TvCastUi.show(this,null,"Arabia TV",false,()->{}));mediaBar.addView(tv,new LinearLayout.LayoutParams(0,dp(46),1));root.addView(mediaBar);
        body=column();root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        if(mode.equals("settings")) renderSettings(); else renderChannels();
        LinearLayout nav=new LinearLayout(this);nav.setPadding(dp(8),dp(9),dp(8),dp(9));nav.setBackgroundColor(Color.rgb(16,25,36));
        String[][] tabs={{"all","▦  Canali","▦  القنوات"},{"saved","★  Preferiti","★  المفضلة"},{"recent","◷  Recenti","◷  الأخيرة"},{"settings","⚙  Altro","⚙  المزيد"}};
        for(String[] tab:tabs) {
            Button item=button(tab[arabic?2:1],mode.equals(tab[0])?Ui.ACCENT:Ui.MUTED);item.setTag("nav-"+tab[0]);
            item.setTextSize(11);item.setPadding(0,0,0,0);item.setBackgroundColor(Color.TRANSPARENT);
            item.setOnClickListener(view->{mode=tab[0];query="";category="ALL";country="ALL";render();});
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(48),1));
        }
        root.addView(nav);
    }
    private void renderChannels() {
        LinearLayout intro=column();intro.setPadding(dp(22),dp(7),dp(22),dp(8));
        TextView eyebrow=text(t("IL MONDO ARABO, A PORTATA DI TAP","العالم العربي، بلمسة واحدة"),10,Ui.ACCENT,true);
        eyebrow.setLetterSpacing(arabic?0:.08f);intro.addView(eyebrow);
        String heading=mode.equals("saved")?t("Le tue frequenze.","قنواتك المفضلة."):mode.equals("recent")?t("Bentornato in onda.","عد إلى المشاهدة."):t("Accendi la tua serata.","ابدأ سهرتك.");
        TextView title=text(heading,28,Ui.TEXT,true);title.setPadding(0,dp(8),0,dp(4));intro.addView(title);
        TextView sub=text(t("Canali arabi · fonti ufficiali · playlist personali","قنوات عربية · مصادر رسمية · قوائم خاصة"),12,Ui.MUTED,false);intro.addView(sub);body.addView(intro);
        EditText search=new EditText(this);search.setTag("search");search.setSingleLine(true);search.setTextSize(16);search.setTextColor(Ui.TEXT);search.setHintTextColor(Ui.MUTED);
        search.setHint(t("Cerca un canale…","ابحث عن قناة…"));search.setContentDescription(t("Cerca un canale","البحث عن قناة"));
        search.setPadding(dp(16),0,dp(16),0);search.setBackground(Ui.shape(this,Ui.SURFACE,13));search.setText(query);
        LinearLayout.LayoutParams searchLayout=new LinearLayout.LayoutParams(-1,dp(50));searchLayout.setMargins(dp(20),dp(9),dp(20),dp(9));body.addView(search,searchLayout);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int start,int before,int count){query=s.toString();filter();}public void afterTextChanged(Editable e){} });

        HorizontalScrollView horizontal=new HorizontalScrollView(this);horizontal.setHorizontalScrollBarEnabled(false);
        LinearLayout chips=new LinearLayout(this);chips.setPadding(dp(16),0,dp(16),0);horizontal.addView(chips);
        for(String[] cat:CATEGORIES) {
            Button chip=button(cat[arabic?2:1],category.equals(cat[0])?Ui.BG:Ui.MUTED);chip.setTag("category-"+cat[0]);
            chip.setBackground(Ui.shape(this,category.equals(cat[0])?Ui.ACCENT:Ui.SURFACE,23));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(44));lp.setMargins(dp(4),0,dp(4),0);chips.addView(chip,lp);
            chip.setOnClickListener(view->{category=cat[0];for(int i=0;i<chips.getChildCount();i++){Button other=(Button)chips.getChildAt(i);boolean selected=other==chip;other.setTextColor(selected?Ui.BG:Ui.MUTED);other.setBackground(Ui.shape(this,selected?Ui.ACCENT:Ui.SURFACE,23));}filter();});
        }
        body.addView(horizontal,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout tools=new LinearLayout(this);tools.setPadding(dp(20),dp(4),dp(18),dp(3));tools.setGravity(Gravity.CENTER_VERTICAL);
        counter=text("",12,Ui.MUTED,false);counter.setTag("count");tools.addView(counter,new LinearLayout.LayoutParams(0,-2,1));
        Spinner countries=new Spinner(this);List<String> codes=new ArrayList<>(),labels=new ArrayList<>();codes.add("ALL");labels.add(t("🌐 Tutti i Paesi","🌐 كل الدول"));
        Set<String> available=new LinkedHashSet<>();for(Channel channel:catalog)available.add(channel.country);
        for(String[] entry:COUNTRIES) if(available.contains(entry[0])){codes.add(entry[0]);labels.add(entry[arabic?2:1]);}
        ArrayAdapter<String> spinnerAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels);countries.setAdapter(spinnerAdapter);countries.setContentDescription(t("Filtra per Paese","تصفية حسب الدولة"));
        countries.setSelection(Math.max(0,codes.indexOf(country)));countries.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> parent){}public void onItemSelected(AdapterView<?> parent,View view,int position,long id){country=codes.get(position);filter();}});
        tools.addView(countries,new LinearLayout.LayoutParams(dp(176),dp(46)));body.addView(tools);
        empty=text("",15,Ui.MUTED,false);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(24),dp(18),dp(24),dp(18));empty.setVisibility(View.GONE);empty.setTag("empty");body.addView(empty);
        RecyclerView grid=new RecyclerView(this);grid.setTag("channels");grid.setLayoutManager(new GridLayoutManager(this,getResources().getConfiguration().screenWidthDp>=700?4:2));
        grid.setPadding(dp(12),0,dp(12),dp(14));grid.setClipToPadding(false);adapter=new ChannelAdapter();grid.setAdapter(adapter);
        body.addView(grid,new LinearLayout.LayoutParams(-1,0,1));filter();
    }
    private void filter() {
        if(adapter==null||counter==null||mode.equals("settings"))return;
        List<Channel> filtered=new ArrayList<>();
        for(Channel channel:catalog) {
            if(mode.equals("saved")&&!favorites.contains(channel.id))continue;
            if(mode.equals("recent")&&!recent.contains(channel.id))continue;
            if(!country.equals("ALL")&&!channel.country.equals(country))continue;
            if(category.equals("DIRECT")&&channel.stream.isEmpty())continue;
            if(!category.equals("ALL")&&!category.equals("DIRECT")&&!channel.category.equals(category))continue;
            if(channel.matches(query))filtered.add(channel);
        }
        if(mode.equals("recent"))filtered.sort((a,b)->Integer.compare(recent.indexOf(a.id),recent.indexOf(b.id)));
        visible=filtered;adapter.notifyDataSetChanged();
        counter.setText(visible.size()+t(" canali"," قناة"));
        empty.setText(mode.equals("saved")?t("La tua lista è vuota. Tocca ★ su un canale per salvarlo.","قائمتك فارغة. اضغط ★ لحفظ قناة."):mode.equals("recent")?t("I canali che apri appariranno qui.","ستظهر هنا القنوات التي تفتحها."):t("Nessun canale trovato. Prova un altro Paese o titolo.","لم نجد قناة. جرّب دولة أو اسماً آخر."));
        empty.setVisibility(visible.isEmpty()?View.VISIBLE:View.GONE);
    }
    private String countryLabel(String code) { for(String[] entry:COUNTRIES)if(entry[0].equals(code))return entry[arabic?2:1];return code; }
    private void favorite(Channel channel) {
        if(!favorites.add(channel.id))favorites.remove(channel.id);
        preferences.edit().putStringSet("favorites",new HashSet<>(favorites)).apply();filter();
    }
    private void markRecent(Channel channel) {
        recent.remove(channel.id);recent.add(0,channel.id);if(recent.size()>30)recent.remove(recent.size()-1);
        preferences.edit().putString("recent",new JSONArray(recent).toString()).apply();
    }
    private void open(Channel channel) {
        if(!channel.stream.isEmpty()) watch(channel);
        else details(channel);
    }
    private void watch(Channel channel) {
        stopService(new Intent(this,com.mourad.radiomaroc.RadioService.class));
        markRecent(channel);
        startActivity(new Intent(this,PlayerActivity.class).putExtra("title",arabic?channel.arabic:channel.name)
            .putExtra("stream",channel.stream).putExtra("official",channel.official).putExtra("arabic",arabic));
    }
    private void details(Channel channel) {
        String message=countryLabel(channel.country)+"\n\n"+t("La disponibilità dipende dall’emittente e dal Paese. Alcuni servizi richiedono un account o un abbonamento.","يتوقف التوفر على القناة والدولة. قد تتطلب بعض الخدمات حساباً أو اشتراكاً.");
        AlertDialog.Builder dialog=new AlertDialog.Builder(this).setTitle(channel.name+" · "+channel.arabic).setMessage(message).setNegativeButton(t("Chiudi","إغلاق"),null);
        if(!channel.stream.isEmpty())dialog.setPositiveButton(t("Guarda in app","شاهد داخل التطبيق"),(d,w)->watch(channel));
        if(!channel.official.isEmpty())dialog.setNeutralButton(t("Apri sito ufficiale","الموقع الرسمي"),(d,w)->{markRecent(channel);external(channel.official);});
        dialog.show();
    }
    private void external(String url) {
        if(!Channel.isHttps(url))return;
        try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)); }
        catch(Exception error) { toast(t("Nessuna app disponibile per aprire il link","لا يوجد تطبيق لفتح الرابط")); }
    }
    private void renderSettings() {
        ScrollView scroll=new ScrollView(this);LinearLayout content=column();content.setPadding(dp(22),dp(18),dp(22),dp(30));scroll.addView(content);body.addView(scroll);
        TextView heading=text(t("La TV, a modo tuo.","التلفزيون، على طريقتك."),28,Ui.TEXT,true);heading.setPadding(0,0,0,dp(23));content.addView(heading);
        panel(content,t("Una finestra sul mondo arabo","نافذة على العالم العربي"),t("Una selezione di canali da 22 Paesi della Lega Araba e di emittenti internazionali. I canali “In app” usano flussi pubblici; gli altri aprono la fonte ufficiale. Il catalogo non comprende ogni canale esistente.","مجموعة قنوات من دول الجامعة العربية الـ٢٢ وقنوات دولية. تستخدم قنوات «داخل التطبيق» بثاً عاماً، وتفتح القنوات الأخرى المصدر الرسمي. لا تضم القائمة كل القنوات الموجودة."));
        panel(content,t("La tua playlist M3U","قائمة M3U الخاصة بك"),t("Importa un file M3U con flussi HTTPS che sei autorizzato a guardare. Il file resta sul telefono. Un nuovo import sostituisce la playlist precedente.","استورد ملف M3U ببث HTTPS يحق لك مشاهدته. يبقى الملف على الهاتف. يحل الاستيراد الجديد محل القائمة السابقة."));
        Button importButton=button(t("＋ Importa / sostituisci playlist","＋ استيراد / استبدال القائمة"),Ui.ACCENT);importButton.setTag("import");content.addView(importButton,new LinearLayout.LayoutParams(-1,dp(50)));
        importButton.setOnClickListener(view->{Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");startActivityForResult(intent,501);});
        Button removeImports=button(t("Rimuovi playlist importata","إزالة القائمة المستوردة"),Ui.MUTED);LinearLayout.LayoutParams space=new LinearLayout.LayoutParams(-1,dp(50));space.topMargin=dp(10);content.addView(removeImports,space);
        removeImports.setOnClickListener(view->new AlertDialog.Builder(this).setMessage(t("Rimuovere la playlist importata da questo dispositivo?","هل تريد إزالة القائمة المستوردة من هذا الجهاز؟")).setNegativeButton(t("Annulla","إلغاء"),null).setPositiveButton(t("Rimuovi","إزالة"),(d,w)->{if(getFileStreamPath("imports.json").exists()&&!deleteFile("imports.json")){toast(t("Impossibile rimuovere il file","تعذرت إزالة الملف"));return;}loadCatalog();toast(t("Playlist rimossa","تمت إزالة القائمة"));}).show());
        panel(content,t("Preferiti privati, nessun account","مفضلة خاصة، دون حساب"),t("Preferiti, cronologia e playlist rimangono sul dispositivo. La visione contatta l’emittente o il suo fornitore video. Nessun sistema pubblicitario o analytics è incluso nell’app.","تُحفظ المفضلة والسجل والقائمة على الجهاز. تتصل المشاهدة بالقناة أو بمزود الفيديو. لا يحتوي التطبيق على إعلانات أو أدوات تحليل."));
        Button clear=button(t("Cancella preferiti e cronologia","مسح المفضلة والسجل"),Ui.MUTED);content.addView(clear,new LinearLayout.LayoutParams(-1,dp(50)));
        clear.setOnClickListener(view->new AlertDialog.Builder(this).setMessage(t("Cancellare preferiti e cronologia?","هل تريد مسح المفضلة والسجل؟")).setNegativeButton(t("Annulla","إلغاء"),null).setPositiveButton(t("Cancella","مسح"),(d,w)->{favorites.clear();recent.clear();preferences.edit().remove("favorites").remove("recent").apply();toast(t("Dati cancellati","تم مسح البيانات"));}).show());
        TextView version=text("ARABIA TV + RADIO 1.1.0\n"+t("Progetto indipendente · Nessuna affiliazione con le emittenti.","مشروع مستقل · غير تابع للقنوات."),11,Ui.MUTED,false);version.setPadding(0,dp(26),0,0);content.addView(version);
    }
    private void panel(LinearLayout parent,String title,String description) {
        TextView heading=text(title,17,Ui.TEXT,true);heading.setPadding(0,0,0,dp(9));parent.addView(heading);
        TextView paragraph=text(description,13,Ui.MUTED,false);paragraph.setLineSpacing(dp(3),1);paragraph.setPadding(0,0,0,dp(21));parent.addView(paragraph);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request!=501||result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();toast(t("Importazione…","جارٍ الاستيراد…"));
        new Thread(()->{
            try(java.io.InputStream input=getContentResolver().openInputStream(uri)) {
                if(input==null)throw new IllegalArgumentException();
                PlaylistParser.Result imported=PlaylistParser.parse(CatalogStore.read(input));
                if(imported.channels.isEmpty())throw new IllegalArgumentException();
                CatalogStore.saveImports(this,imported.channels);
                runOnUiThread(()->{loadCatalog();mode="all";country="USER";category="ALL";query="";render();toast(imported.channels.size()+t(" canali importati; ignorati: "," قناة مستوردة؛ تم تجاهل: ")+imported.skipped);});
            } catch(Exception error) { runOnUiThread(()->toast(t("File non valido: scegli una playlist M3U HTTPS, massimo 2 MB.","ملف غير صالح: اختر قائمة M3U ببث HTTPS، بحد أقصى ٢ ميغابايت."))); }
        },"playlist-import").start();
    }
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    @Override protected void onSaveInstanceState(Bundle state) { state.putString("mode",mode);state.putString("country",country);state.putString("category",category);state.putString("query",query);super.onSaveInstanceState(state); }
    private void handleBack(){if(!mode.equals("all")){mode="all";country="ALL";category="ALL";query="";render();}else finish();}

    private final class ChannelAdapter extends RecyclerView.Adapter<ChannelHolder> {
        @Override public ChannelHolder onCreateViewHolder(ViewGroup parent,int type) {
            LinearLayout card=column();card.setPadding(dp(13),dp(12),dp(10),dp(10));card.setBackground(Ui.shape(MainActivity.this,Ui.SURFACE,17));
            RecyclerView.LayoutParams layout=new RecyclerView.LayoutParams(-1,dp(184));layout.setMargins(dp(7),dp(7),dp(7),dp(7));card.setLayoutParams(layout);
            LinearLayout top=new LinearLayout(MainActivity.this);top.setGravity(Gravity.CENTER_VERTICAL);
            TextView monogram=text("",26,Ui.ACCENT,true);top.addView(monogram,new LinearLayout.LayoutParams(0,dp(48),1));
            Button star=button("☆",Ui.MUTED);star.setTextSize(25);star.setMinWidth(0);star.setMinimumWidth(0);star.setPadding(0,0,0,0);top.addView(star,new LinearLayout.LayoutParams(dp(44),dp(44)));card.addView(top);
            TextView arName=text("",19,Ui.TEXT,true);arName.setMaxLines(1);arName.setEllipsize(TextUtils.TruncateAt.END);arName.setTextDirection(View.TEXT_DIRECTION_RTL);card.addView(arName);
            TextView latin=text("",12,Ui.MUTED,false);latin.setSingleLine(true);latin.setEllipsize(TextUtils.TruncateAt.END);card.addView(latin);
            TextView location=text("",10,Ui.MUTED,false);location.setPadding(0,dp(8),0,0);location.setSingleLine(true);card.addView(location);
            TextView availability=text("",10,Ui.ACCENT,true);availability.setPadding(0,dp(7),0,0);card.addView(availability);
            return new ChannelHolder(card,monogram,star,arName,latin,location,availability);
        }
        @Override public void onBindViewHolder(ChannelHolder holder,int position) {
            Channel channel=visible.get(position);String compact=channel.name.replaceAll("[^A-Za-z0-9]","");if(compact.length()>3)compact=compact.substring(0,3);
            holder.monogram.setText(compact.toUpperCase(java.util.Locale.ROOT));holder.arName.setText(channel.arabic);holder.latin.setText(channel.name);
            holder.location.setText(countryLabel(channel.country));holder.availability.setText(channel.stream.isEmpty()?t("↗  SITO UFFICIALE","↗  الموقع الرسمي"):t("▶  DIRETTA IN APP","▶  مباشر داخل التطبيق"));
            holder.star.setText(favorites.contains(channel.id)?"★":"☆");holder.star.setTextColor(favorites.contains(channel.id)?Ui.ACCENT:Ui.MUTED);
            holder.star.setContentDescription((favorites.contains(channel.id)?t("Rimuovi dai preferiti: ","إزالة من المفضلة: "):t("Aggiungi ai preferiti: ","إضافة إلى المفضلة: "))+channel.name);
            holder.star.setOnClickListener(view->favorite(channel));holder.itemView.setOnClickListener(view->open(channel));holder.itemView.setOnLongClickListener(view->{details(channel);return true;});
            holder.itemView.setContentDescription(channel.arabic+", "+channel.name+", "+holder.availability.getText());holder.itemView.setFocusable(true);
        }
        @Override public int getItemCount(){return visible.size();}
    }
    private static final class ChannelHolder extends RecyclerView.ViewHolder {
        final TextView monogram,arName,latin,location,availability;final Button star;
        ChannelHolder(View root,TextView monogram,Button star,TextView arName,TextView latin,TextView location,TextView availability){super(root);this.monogram=monogram;this.star=star;this.arName=arName;this.latin=latin;this.location=location;this.availability=availability;}
    }
}
