package it.mourad.arabiatv;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;

/** Standard UPnP AVTransport controller. Discovery and control are restricted to LAN devices. */
public final class DlnaClient {
    public static final class Device {
        public final String name,service;public final URI control;
        public Device(String name,String service,URI control){this.name=name;this.service=service;this.control=control;}
    }
    public static boolean isLocal(URI uri) {
        try {
            if(!("http".equals(uri.getScheme())||"https".equals(uri.getScheme()))||uri.getHost()==null||uri.getUserInfo()!=null)return false;
            InetAddress[] addresses=InetAddress.getAllByName(uri.getHost());
            if(addresses.length==0)return false;
            for(InetAddress a:addresses)if(!(a.isSiteLocalAddress()||a.isLinkLocalAddress()||a.isLoopbackAddress()))return false;
            return true;
        }catch(Exception e){return false;}
    }
    public static List<Device> discover() throws Exception {
        Set<String> locations=new LinkedHashSet<>();
        try(DatagramSocket socket=new DatagramSocket()) {
            socket.setSoTimeout(500);
            for(String st:new String[]{"urn:schemas-upnp-org:device:MediaRenderer:1","urn:schemas-upnp-org:service:AVTransport:1"}) {
                String message="M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: "+st+"\r\n\r\n";
                byte[] data=message.getBytes(StandardCharsets.US_ASCII);
                socket.send(new DatagramPacket(data,data.length,InetAddress.getByName("239.255.255.250"),1900));
            }
            long deadline=System.currentTimeMillis()+5500;
            while(System.currentTimeMillis()<deadline&&locations.size()<12) {
                byte[] buffer=new byte[8192];DatagramPacket response=new DatagramPacket(buffer,buffer.length);
                try{socket.receive(response);}catch(SocketTimeoutException timeout){continue;}
                for(String line:new String(response.getData(),0,response.getLength(),StandardCharsets.UTF_8).split("\r?\n")) {
                    int colon=line.indexOf(':');if(colon<0||!line.substring(0,colon).trim().equalsIgnoreCase("location"))continue;
                    try { URI uri=new URI(line.substring(colon+1).trim());
                        if(isLocal(uri)&&Arrays.asList(InetAddress.getAllByName(uri.getHost())).contains(response.getAddress()))locations.add(uri.toString());
                    }catch(Exception ignored){}
                }
            }
        }
        List<Device> devices=new ArrayList<>();Set<String> controls=new HashSet<>();
        for(String location:locations)try {
            URI uri=URI.create(location);Device device=parseDescription(request(uri,null,null),uri);
            if(device!=null&&controls.add(device.control.toString()))devices.add(device);
        }catch(Exception ignored){}
        return devices;
    }
    private static Document xml(String text) throws Exception {
        if(text.toUpperCase(Locale.ROOT).contains("<!DOCTYPE")||text.toUpperCase(Locale.ROOT).contains("<!ENTITY"))throw new IOException("XML non consentito");
        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();factory.setNamespaceAware(true);factory.setExpandEntityReferences(false);
        return factory.newDocumentBuilder().parse(new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));
    }
    private static String value(Element element,String name) {
        NodeList nodes=element.getElementsByTagNameNS("*",name);return nodes.getLength()==0?"":nodes.item(0).getTextContent().trim();
    }
    public static Device parseDescription(String text,URI location) throws Exception {
        if(!isLocal(location))throw new IOException("Indirizzo TV non locale");
        Document document=xml(text);Element root=document.getDocumentElement();
        String base=value(root,"URLBase");URI baseUri=base.isEmpty()?location:location.resolve(base);
        if(!Objects.equals(baseUri.getHost(),location.getHost()))throw new IOException("Origine TV non valida");
        NodeList services=root.getElementsByTagNameNS("*","service");
        for(int i=0;i<services.getLength();i++) {
            Element service=(Element)services.item(i);String type=value(service,"serviceType");
            if(!type.matches("urn:schemas-upnp-org:service:AVTransport:[1-3]"))continue;
            String target=value(service,"controlURL");if(target.isEmpty())continue;URI control=baseUri.resolve(target);
            if(!isLocal(control)||!Objects.equals(control.getHost(),location.getHost()))throw new IOException("Controllo TV non valido");
            String name=value(root,"friendlyName");return new Device(name.isEmpty()?"TV / DLNA":name,type,control);
        }
        return null;
    }
    public static String escape(String value){return value.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
    public static String envelope(String service,String action,String arguments) {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><u:"+action+" xmlns:u=\""+service+"\">"+arguments+"</u:"+action+"></s:Body></s:Envelope>";
    }
    public static void send(Device device,String action) throws Exception {
        if(!Arrays.asList("Play","Pause","Stop").contains(action))throw new IOException("Comando non supportato");
        call(device,action,"<InstanceID>0</InstanceID>"+(action.equals("Play")?"<Speed>1</Speed>":""));
    }
    public static void play(Device device,String url,String title,boolean audio) throws Exception {
        URI uri=new URI(url);if(uri.getHost()==null||uri.getUserInfo()!=null||!(uri.getScheme().equals("https")||uri.getScheme().equals("http")))throw new IOException("Flusso non valido");
        String path=uri.getPath()==null?"":uri.getPath().toLowerCase(Locale.ROOT);
        String mime=path.contains(".m3u8")?"application/vnd.apple.mpegurl":audio?(path.endsWith(".aac")?"audio/aac":"audio/mpeg"):"video/mp4";
        String metadata="<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\"><item id=\"0\" parentID=\"0\" restricted=\"1\"><dc:title>"+escape(title)+"</dc:title><upnp:class>object.item."+(audio?"audioItem.musicTrack":"videoItem.videoBroadcast")+"</upnp:class><res protocolInfo=\"http-get:*:"+mime+":*\">"+escape(url)+"</res></item></DIDL-Lite>";
        call(device,"SetAVTransportURI","<InstanceID>0</InstanceID><CurrentURI>"+escape(url)+"</CurrentURI><CurrentURIMetaData>"+escape(metadata)+"</CurrentURIMetaData>");send(device,"Play");
    }
    private static void call(Device device,String action,String arguments) throws Exception {
        String result=request(device.control,device.service+"#"+action,envelope(device.service,action,arguments));
        if(!result.trim().isEmpty()&&xml(result).getElementsByTagNameNS("*","Fault").getLength()>0)throw new IOException("Il TV ha rifiutato il comando");
    }
    private static String request(URI uri,String action,String body) throws Exception {
        if(!isLocal(uri))throw new IOException("Consentiti solo dispositivi sulla rete locale");
        HttpURLConnection connection=(HttpURLConnection)uri.toURL().openConnection();connection.setConnectTimeout(3000);connection.setReadTimeout(5000);connection.setInstanceFollowRedirects(false);
        try {
            if(body!=null){connection.setRequestMethod("POST");connection.setDoOutput(true);connection.setRequestProperty("Content-Type","text/xml; charset=utf-8");connection.setRequestProperty("SOAPACTION","\""+action+"\"");byte[] bytes=body.getBytes(StandardCharsets.UTF_8);connection.setFixedLengthStreamingMode(bytes.length);try(OutputStream output=connection.getOutputStream()){output.write(bytes);}}
            int status=connection.getResponseCode();if(status<200||status>=300)throw new IOException("Risposta TV HTTP "+status);
            try(InputStream input=connection.getInputStream();ByteArrayOutputStream output=new ByteArrayOutputStream()){
                byte[] buffer=new byte[4096];int count;while((count=input.read(buffer))!=-1){if(output.size()+count>262144)throw new IOException("Risposta TV troppo grande");output.write(buffer,0,count);}return output.toString(StandardCharsets.UTF_8.name());
            }
        }finally{connection.disconnect();}
    }
}
