package it.mourad.arabiatv;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.WindowInsets;
import android.widget.TextView;

public final class Ui {
    public static final int BG=Color.rgb(11,17,25),SURFACE=Color.rgb(22,32,45),TEXT=Color.rgb(244,247,248),MUTED=Color.rgb(157,174,190),ACCENT=Color.rgb(181,242,120);
    public static int dp(Activity context,float value){return Math.round(value*context.getResources().getDisplayMetrics().density);}
    public static GradientDrawable shape(Activity context,int color,int radius) {
        GradientDrawable shape=new GradientDrawable();shape.setColor(color);shape.setCornerRadius(dp(context,radius));return shape;
    }
    public static TextView text(Activity activity,String text,int size,int color,boolean bold) {
        TextView view=new TextView(activity);view.setText(text);view.setTextSize(size);view.setTextColor(color);
        if(bold)view.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return view;
    }
    public static void insets(Activity activity,View root) {
        root.setOnApplyWindowInsetsListener((view,insets)->{
            if(android.os.Build.VERSION.SDK_INT>=30) {
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());
                view.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            } else view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        root.requestApplyInsets();
    }
}
