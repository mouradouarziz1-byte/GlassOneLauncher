package it.mourad.arabiatv;

import java.net.URI;
import java.text.Normalizer;
import java.util.Locale;

/** Plain Java model, independently tested without Android. */
public final class Channel {
    public final String id, name, arabic, country, category, official, stream;
    public Channel(String id, String name, String arabic, String country, String category, String official, String stream) {
        this.id=id; this.name=name; this.arabic=arabic; this.country=country;
        this.category=category; this.official=official; this.stream=stream;
    }
    public boolean matches(String query) {
        return normalize(name+" "+arabic+" "+country+" "+category).contains(normalize(query));
    }
    public static String normalize(String text) {
        return Normalizer.normalize(text, Normalizer.Form.NFD)
            .replaceAll("[\\p{M}ـ]", "").replace('أ','ا').replace('إ','ا').replace('آ','ا').replace('ى','ي')
            .toLowerCase(Locale.ROOT).trim();
    }
    public static boolean isHttps(String text) {
        try {
            URI uri = new URI(text);
            return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost()!=null
                && !uri.getHost().isEmpty() && uri.getUserInfo()==null && uri.getPort()!=0;
        } catch (Exception error) { return false; }
    }
}
