package it.mourad.arabiatv;

import android.app.*;
import android.content.*;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import android.widget.Toast;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class TvCastUi {
    private static volatile DlnaClient.Device lastDevice;
    public static void show(Activity activity,String stream,String title,boolean audio,Runnable accepted) {
        new AlertDialog.Builder(activity).setTitle("Trasmetti su TV Samsung")
            .setItems(lastDevice==null?new String[]{"Cerca TV sulla rete (DLNA)","Smart View / proietta schermo","Come collegare la TV"}:new String[]{"Cerca TV sulla rete (DLNA)","Smart View / proietta schermo","Come collegare la TV","Controlla ultima TV"},(d,which)->{
                if(which==0) {if(stream==null||stream.isEmpty())help(activity,"Apri prima una diretta In app o una stazione radio, poi premi Trasmetti su TV nel lettore.");else discover(activity,stream,title,audio,accepted);}
                else if(which==1) {
                    help(activity,"Su Galaxy: apri il pannello rapido, scegli Smart View e seleziona la TV. Conferma sulla Samsung se richiesto. La condivisione schermo mantiene il telefono attivo; la compatibilità dipende dal modello. Provo ad aprire le opzioni di trasmissione Android.");
                    try{activity.startActivity(new Intent(Settings.ACTION_CAST_SETTINGS));}catch(ActivityNotFoundException e){Toast.makeText(activity,"Apri Smart View dal pannello rapido del telefono",Toast.LENGTH_LONG).show();}
                } else if(which==3&&lastDevice!=null)controls(activity,lastDevice); else help(activity,"Telefono e TV devono essere sulla stessa rete Wi-Fi. Accendi il TV e autorizza il telefono se richiesto. La modalità DLNA funziona solo sui modelli che espongono AVTransport e sui formati video/audio supportati dal TV. Se il TV non compare o non riproduce il flusso, usa Smart View dal pannello rapido del Galaxy. I canali che aprono un sito ufficiale restano gestiti da quel servizio. Nessun Chromecast è necessario per Smart View; la compatibilità della tua TV va verificata sul modello.");
            }).setNegativeButton("Chiudi",null).show();
    }
    private static void help(Activity activity,String message){new AlertDialog.Builder(activity).setTitle("TV Samsung · collegamento").setMessage(message).setPositiveButton("OK",null).show();}
    private static void discover(Activity activity,String stream,String title,boolean audio,Runnable accepted) {
        AtomicBoolean cancelled=new AtomicBoolean();AlertDialog progress=new AlertDialog.Builder(activity).setTitle("Ricerca TV").setMessage("Cerco dispositivi DLNA sulla rete locale…").setNegativeButton("Annulla",(d,w)->cancelled.set(true)).create();progress.setOnCancelListener(d->cancelled.set(true));progress.show();
        new Thread(()->{
            WifiManager.MulticastLock lock=null;List<DlnaClient.Device> devices=new ArrayList<>();String error=null;
            try {WifiManager wifi=(WifiManager)activity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);if(wifi!=null){lock=wifi.createMulticastLock("ArabiaTvDiscovery");lock.setReferenceCounted(false);lock.acquire();}devices=DlnaClient.discover();}
            catch(Exception e){error="Ricerca non riuscita. Verifica la rete Wi-Fi e riprova.";}
            finally{if(lock!=null&&lock.isHeld())lock.release();}
            final List<DlnaClient.Device> found=devices;final String failure=error;
            activity.runOnUiThread(()->{if(activity.isFinishing()||activity.isDestroyed()||cancelled.get())return;progress.dismiss();if(failure!=null){help(activity,failure);return;}if(found.isEmpty()){help(activity,"Nessun TV DLNA trovato. Controlla che telefono e TV siano sulla stessa rete, che il TV sia acceso e che il router non isoli i dispositivi. Se il tuo modello non espone DLNA, usa Smart View dal pannello rapido del Galaxy.");return;}String[] names=new String[found.size()];for(int i=0;i<names.length;i++)names[i]=found.get(i).name;new AlertDialog.Builder(activity).setTitle("Scegli il televisore").setItems(names,(d,which)->start(activity,found.get(which),stream,title,audio,accepted)).setNegativeButton("Annulla",null).show();});
        },"tv-discovery").start();
    }
    private static void start(Activity activity,DlnaClient.Device device,String stream,String title,boolean audio,Runnable accepted) {
        Toast.makeText(activity,"Invio al TV…",Toast.LENGTH_SHORT).show();new Thread(()->{
            try {DlnaClient.play(device,stream,title,audio);activity.runOnUiThread(()->{if(activity.isFinishing()||activity.isDestroyed())return;accepted.run();controls(activity,device);});}
            catch(Exception e){activity.runOnUiThread(()->{if(!activity.isFinishing())help(activity,"Il TV non ha accettato il flusso. Il formato o l’indirizzo potrebbe non essere supportato. La riproduzione sul telefono resta disponibile; puoi usare Smart View.");});}
        },"tv-play").start();
    }
    private static void controls(Activity activity,DlnaClient.Device device) {
        lastDevice=device;
        new AlertDialog.Builder(activity).setTitle(device.name).setMessage("Comando di avvio inviato. Verifica sul televisore che audio/video siano partiti. Il TV scarica il flusso direttamente dall’emittente. Il timer della radio non ferma la riproduzione sul televisore.")
            .setPositiveButton("Pausa",(d,w)->command(activity,device,"Pause"))
            .setNeutralButton("Riprendi",(d,w)->command(activity,device,"Play"))
            .setNegativeButton("Ferma TV",(d,w)->command(activity,device,"Stop")).show();
    }
    private static void command(Activity activity,DlnaClient.Device device,String action) {
        new Thread(()->{try {DlnaClient.send(device,action);activity.runOnUiThread(()->{if(activity.isFinishing())return;if(action.equals("Stop")){lastDevice=null;Toast.makeText(activity,"Comando di arresto inviato al TV",Toast.LENGTH_LONG).show();}else controls(activity,device);});}catch(Exception e){activity.runOnUiThread(()->{if(!activity.isFinishing())help(activity,"Il TV non risponde al comando. Usa il telecomando o riprova.");});}},"tv-control").start();
    }
}
