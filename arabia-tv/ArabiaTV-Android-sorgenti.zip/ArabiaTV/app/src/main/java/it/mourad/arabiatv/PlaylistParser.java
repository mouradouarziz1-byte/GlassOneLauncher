package it.mourad.arabiatv;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Imports user-selected M3U entries. No URL downloads, credentials or header overrides. */
public final class PlaylistParser {
    public static final int MAX_BYTES=2*1024*1024, MAX_CHANNELS=5000;
    private static final Pattern ATTRIBUTE=Pattern.compile("([\\w-]+)=\"([^\"]*)\"");
    public static final class Result {
        public final List<Channel> channels=new ArrayList<>();
        public int skipped;
    }
    public static Result parse(String text) {
        if(text.getBytes(StandardCharsets.UTF_8).length>MAX_BYTES) throw new IllegalArgumentException("Playlist troppo grande");
        Result result=new Result(); Set<String> urls=new HashSet<>();
        String name="", group="Playlist";
        for(String raw:text.replace("\uFEFF","").split("\\r?\\n")) {
            String line=raw.trim();
            if(line.startsWith("#EXTINF:")) {
                name=""; group="Playlist";
                // The first comma outside quoted attributes separates metadata from display name.
                boolean quoted=false; int comma=-1;
                for(int i=0;i<line.length();i++) {
                    if(line.charAt(i)=='\"') quoted=!quoted;
                    else if(line.charAt(i)==','&&!quoted){comma=i;break;}
                }
                if(comma>=0) name=line.substring(comma+1).trim();
                Matcher attrs=ATTRIBUTE.matcher(line.substring(0,comma>=0?comma:line.length()));
                while(attrs.find()) {
                    if(attrs.group(1).equals("tvg-name")&&name.isEmpty())name=attrs.group(2);
                    if(attrs.group(1).equals("group-title"))group=attrs.group(2);
                }
            } else if(!line.isEmpty()&&!line.startsWith("#")) {
                if(!Channel.isHttps(line)||!urls.add(line)||result.channels.size()>=MAX_CHANNELS) result.skipped++;
                else {
                    String label=name.isEmpty()?"Canale "+(result.channels.size()+1):name;
                    label=label.substring(0,Math.min(120,label.length()));
                    result.channels.add(new Channel("user-"+digest(line),label,label,"USER",group,"",line));
                }
                name=""; group="Playlist";
            }
        }
        return result;
    }
    private static String digest(String text) {
        try {
            byte[] bytes=MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex=new StringBuilder();
            for(int i=0;i<10;i++)hex.append(String.format(java.util.Locale.ROOT,"%02x",bytes[i]));
            return hex.toString();
        } catch(Exception error){throw new IllegalStateException(error);}
    }
}
