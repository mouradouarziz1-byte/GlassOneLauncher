package it.mourad.arabiatv;
import org.junit.Test;
import static org.junit.Assert.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.io.*;

public class DlnaClientTest {
    @Test public void parsesNamespacedRendererAndRelativeControlURL() throws Exception {
        String xml="<root xmlns='urn:schemas-upnp-org:device-1-0'><device><friendlyName>Samsung Sala</friendlyName><serviceList><service><serviceType>urn:schemas-upnp-org:service:AVTransport:1</serviceType><controlURL>/upnp/control</controlURL></service></serviceList></device></root>";
        DlnaClient.Device tv=DlnaClient.parseDescription(xml,URI.create("http://127.0.0.1:9197/description.xml"));
        assertEquals("Samsung Sala",tv.name);assertEquals("/upnp/control",tv.control.getPath());
    }
    @Test public void rejectsPublicTargetsCredentialsAndCrossHostControls() throws Exception {
        assertFalse(DlnaClient.isLocal(URI.create("http://203.0.113.3/control")));
        assertFalse(DlnaClient.isLocal(URI.create("http://user:pass@127.0.0.1/control")));
        String xml="<root><service><serviceType>urn:schemas-upnp-org:service:AVTransport:1</serviceType><controlURL>http://203.0.113.3/control</controlURL></service></root>";
        try{DlnaClient.parseDescription(xml,URI.create("http://127.0.0.1/desc"));fail();}catch(java.io.IOException expected){}
    }
    @Test public void rejectsExternalEntities() throws Exception {
        try{DlnaClient.parseDescription("<!DOCTYPE root [<!ENTITY bad SYSTEM 'file:///etc/passwd'>]><root/>",URI.create("http://127.0.0.1/desc"));fail();}catch(java.io.IOException expected){}
    }
    @Test public void sendsSetUriPlayPauseStopToMockTvWithEscapedMetadata() throws Exception {
        List<String> actions=Collections.synchronizedList(new ArrayList<>());List<String> bodies=Collections.synchronizedList(new ArrayList<>());
        ServerSocket server=new ServerSocket(0,8,InetAddress.getByName("127.0.0.1"));
        Thread worker=new Thread(()->{try{for(int i=0;i<4;i++){try(Socket socket=server.accept()){
            socket.setSoTimeout(5000);BufferedReader reader=new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.UTF_8));String line;int length=0;String action="";
            while((line=reader.readLine())!=null&&!line.isEmpty()){int colon=line.indexOf(':');if(colon<0)continue;String key=line.substring(0,colon);String value=line.substring(colon+1).trim();if(key.equalsIgnoreCase("Content-Length"))length=Integer.parseInt(value);if(key.equalsIgnoreCase("SOAPACTION"))action=value;}
            char[] chars=new char[length];int offset=0;while(offset<length){int n=reader.read(chars,offset,length-offset);if(n<0)break;offset+=n;}actions.add(action);bodies.add(new String(chars,0,offset));
            byte[] response="<s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'><s:Body/></s:Envelope>".getBytes(StandardCharsets.UTF_8);
            socket.getOutputStream().write(("HTTP/1.1 200 OK\r\nContent-Type: text/xml\r\nContent-Length: "+response.length+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));socket.getOutputStream().write(response);socket.getOutputStream().flush();
        }}}catch(IOException ignored){}},"mock-tv");worker.setDaemon(true);worker.start();
        try {
            DlnaClient.Device tv=new DlnaClient.Device("Test TV","urn:schemas-upnp-org:service:AVTransport:1",URI.create("http://127.0.0.1:"+server.getLocalPort()+"/control"));
            DlnaClient.play(tv,"https://example.org/live.m3u8?a=1&b=2","Medi & TV",false);DlnaClient.send(tv,"Pause");DlnaClient.send(tv,"Stop");
            assertEquals(4,actions.size());assertTrue(actions.get(0).contains("SetAVTransportURI"));assertTrue(actions.get(1).contains("#Play"));assertTrue(actions.get(2).contains("#Pause"));assertTrue(actions.get(3).contains("#Stop"));assertTrue(bodies.get(0).contains("a=1&amp;b=2"));assertTrue(bodies.get(0).contains("Medi &amp;amp; TV"));
        }finally{server.close();worker.join(1000);}
    }
    @Test public void originalRadioCatalogIsPreserved() {assertEquals(22,com.mourad.radiomaroc.StationRepository.all().size());assertNotNull(com.mourad.radiomaroc.StationRepository.find("medi1"));}
}
