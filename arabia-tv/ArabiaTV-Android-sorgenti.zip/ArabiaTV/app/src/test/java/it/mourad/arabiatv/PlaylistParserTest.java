package it.mourad.arabiatv;
import org.junit.Test;
import static org.junit.Assert.*;
public class PlaylistParserTest {
    @Test public void arabicDiacriticsAndLatinAccentsAreNormalized() {
        Channel channel=new Channel("1","Télé Maroc","قَنَاةُ الأُولَى","MA","General","","");
        assertTrue(channel.matches("tele maroc"));assertTrue(channel.matches("الاولى"));
    }
    @Test public void importsQuotedCommaAndGroupAndDeduplicates() {
        String source="#EXTM3U\n#EXTINF:-1 group-title=\"News, World\",Al Jazeera\nhttps://example.com/live.m3u8\nhttps://example.com/live.m3u8\n";
        PlaylistParser.Result result=PlaylistParser.parse(source);
        assertEquals(1,result.channels.size());assertEquals("Al Jazeera",result.channels.get(0).name);
        assertEquals("News, World",result.channels.get(0).category);assertEquals(1,result.skipped);
    }
    @Test public void blocksCleartextCredentialsAndUnsafeSchemes() {
        PlaylistParser.Result result=PlaylistParser.parse("#EXTM3U\nhttp://example.com/a\nfile:///etc/passwd\nhttps://user:password@example.com/live\nhttps://example.com/ok.m3u8\n");
        assertEquals(1,result.channels.size());assertEquals(3,result.skipped);
    }
    @Test public void eachUnnamedStreamGetsANewNameAndStableId() {
        String content="https://example.com/a.m3u8\nhttps://example.com/b.m3u8";
        PlaylistParser.Result first=PlaylistParser.parse(content),second=PlaylistParser.parse(content);
        assertEquals("Canale 1",first.channels.get(0).name);assertEquals("Canale 2",first.channels.get(1).name);
        assertEquals(first.channels.get(0).id,second.channels.get(0).id);assertNotEquals(first.channels.get(0).id,first.channels.get(1).id);
    }
    @Test(expected=IllegalArgumentException.class) public void oversizedPlaylistIsRejected() { PlaylistParser.parse("x".repeat(PlaylistParser.MAX_BYTES+1)); }
    @Test public void utf8BomAndWindowsNewlinesWork() { assertEquals("قناة",PlaylistParser.parse("\uFEFF#EXTM3U\r\n#EXTINF:-1,قناة\r\nhttps://example.com/a.m3u8\r\n").channels.get(0).name); }
}
