# Arabia TV · التلفزيون العربي

App Android nativa, in italiano e arabo, per esplorare 64 canali di emittenti arabe e internazionali. Il catalogo copre i 22 Paesi della Lega Araba, oltre alle emittenti internazionali in lingua araba. È una selezione editoriale: non contiene ogni canale esistente e non garantisce disponibilità mondiale.

## Funzioni

- Ricerca in caratteri arabi e latini, con normalizzazione degli accenti.
- Filtri per Paese, genere e «In app».
- Preferiti e cronologia memorizzati sul telefono.
- Interfaccia araba con RTL e italiano.
- Player Android Media3 per HLS, selezione del limite di qualità, risparmio dati, rotazione e gestione degli errori.
- Flussi pubblici selezionati, senza proxy, autenticazione o decrittazione.
- Collegamento alla pagina ufficiale quando non è disponibile un flusso diretto verificato.
- Importazione locale di playlist M3U HTTPS personali, fino a 2 MB / 5.000 voci. Il nuovo import sostituisce il precedente.
- Nessun login dell’app, nessun sistema pubblicitario, nessun analytics e nessun abbonamento venduto dall’app.

I flussi candidati vengono controllati durante la build: deve essere raggiungibile un manifest HLS e almeno un segmento multimediale. I flussi non disponibili o cifrati diventano voci con collegamento al sito ufficiale. Questa verifica è svolta dalla regione del runner GitHub; non prova la disponibilità dal Paese dell’utente e non costituisce una licenza di distribuzione. Le emittenti possono cambiare indirizzi o applicare restrizioni territoriali e di abbonamento. L’app non aggira queste restrizioni.

Le voci «Sito ufficiale» possono portare al portale dell’emittente, da cui selezionare il relativo canale. Alcune emittenti presenti nel catalogo trasmettono anche in lingue locali, ad esempio amazigh o somalo. I marchi e i programmi restano dei rispettivi titolari. Il progetto è indipendente dalle emittenti.

## Compilazione

Requisiti: JDK 17, Gradle 8.9, Android SDK Platform 35 e Build Tools 35.0.0.

```bash
python3 tools/validate_catalog.py
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`. Il pacchetto è `it.mourad.arabiatv`, versione 1.0.0; Android minimo 8.0 / API 26. La build debug è adatta a installazione personale e prove; la pubblicazione su Google Play richiede una release firmata e verifica dei requisiti correnti.

La procedura GitHub esegue anche `tools/verify_streams.py`, conserva `stream-report.json`, verifica la firma dell’APK e avvia le prove dell’interfaccia su emulatore Android. Consultare l’esito effettivo della run prima di considerare questi controlli superati.

## Test

- Test JUnit del parser M3U: UTF-8/BOM, metadati con virgole, duplicati, limiti, URL HTTPS e ricerca araba.
- Validazione del catalogo: ID univoci, URL HTTPS, copertura dei 22 Paesi.
- Prove Espresso: avvio, ricerca araba, stato vuoto, pagina playlist e cambio lingua; prova di riproduzione reale di una diretta pubblica nel lettore Android.
- Test Python della verifica HLS, compresi manifest compressi gzip e rifiuto di flussi cifrati.
- Verifica HLS dalla rete del runner e controllo dell’archivio/firma APK.

Non è inclusa una guida programmi EPG: nessun programma in onda viene inventato. Casting, registrazione, contenuti a pagamento e playlist esterne preconfezionate non sono inclusi.

## Origine del catalogo

Il file `app/src/main/assets/channels.json` conserva per ogni voce la pagina ufficiale. `tools/catalog_seed.py` permette di rigenerare la selezione editoriale. Fra le fonti primarie consultate il 4 novembre 2026:

- [SNRT Live](https://snrtlive.ma/ar/node/4019)
- [Al Jazeera Live](https://www.aljazeera.net/video/live)
- [Al Arabiya Live](https://live.alarabiya.net/)
- [Sky News Arabia Live](https://www.skynewsarabia.com/livestream-%D8%A7%D9%84%D8%A8%D8%AB-%D8%A7%D9%84%D9%85%D8%A8%D8%A7%D8%B4%D8%B1)
- [Qatar TV](https://www.qtv.qa/)
- [Medi 1 TV](https://www.medi1tv.com/fr/live)
- [Shahid Live](https://shahid.mbc.net/ar/livestream)
- [TRT Arabi](https://www.trtarabi.com/)
- [Android Media3](https://developer.android.com/media/media3/exoplayer/hls)

## Dati e permessi

L’app richiede solo Internet. Le playlist vengono lette attraverso il selettore file di Android; non viene chiesto accesso generale alla memoria. Preferiti, cronologia e playlist importate restano nella memoria privata dell’app e il backup Android è disabilitato. Aprire un sito o riprodurre una diretta contatta l’emittente e i suoi fornitori; valgono le relative condizioni e politiche privacy. Le playlist personali non vengono caricate su GitHub o altri servizi dall’app.

## Licenza

Codice originale: MIT. Canali, marchi, programmi e servizi esterni conservano i propri diritti e condizioni. Il codice non concede licenze sulle trasmissioni.
