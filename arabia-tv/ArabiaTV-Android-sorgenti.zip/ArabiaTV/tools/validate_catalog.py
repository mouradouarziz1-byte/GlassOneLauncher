#!/usr/bin/env python3
import json
from pathlib import Path
from urllib.parse import urlparse
data=json.loads((Path(__file__).resolve().parents[1]/"app/src/main/assets/channels.json").read_text())
ids=set()
for channel in data:
    assert channel["id"] not in ids
    ids.add(channel["id"])
    for key in ("name","arabic","country","category","official"):assert channel[key]
    for key in ("official","stream"):
        if channel[key]:
            url=urlparse(channel[key]);assert url.scheme=="https" and url.hostname and not url.username
assert len(data)>=60
assert len({c['country'] for c in data if c['country']!='WORLD'})==22
print("Catalog validation passed:",len(data),"channels across 22 Arab League countries and international broadcasters")
