#!/usr/bin/env python3
"""Probe public HLS manifests and their media. Failed streams become official-site entries.
This checks availability from the build region, not a worldwide playback guarantee.
No authentication, spoofed headers, decryption, tokens or geographic bypass is used.
"""
import concurrent.futures
import datetime
import gzip
import json
from pathlib import Path
import urllib.parse
import urllib.request

root=Path(__file__).resolve().parents[1]
path=root/"app/src/main/assets/channels.json"
catalog=json.loads(path.read_text())
def load(url,limit=262144):
    if urllib.parse.urlparse(url).scheme!="https":raise ValueError("HTTPS required")
    request=urllib.request.Request(url,headers={"User-Agent":"ArabiaTV/1.0 (Android)","Range":"bytes=0-262143"})
    with urllib.request.urlopen(request,timeout=12) as response:
        if urllib.parse.urlparse(response.url).scheme!="https":raise ValueError("Insecure redirect")
        return response.read(limit),response.url

def probe(channel):
    result={"id":channel["id"],"name":channel["name"],"ok":False,"reason":""}
    try:
        body,url=load(channel["stream"])
        for depth in range(4):
            if body.startswith(b"\x1f\x8b"):body=gzip.decompress(body)
            text=body.decode("utf-8-sig")
            if not text.lstrip().startswith("#EXTM3U"):raise ValueError("Not an HLS manifest")
            lines=[line.strip() for line in text.splitlines() if line.strip()]
            if any(line.startswith("#EXT-X-KEY:") and "METHOD=NONE" not in line for line in lines):
                raise ValueError("Encrypted manifest: use official service")
            entries=[line for line in lines if not line.startswith("#")]
            if not entries:raise ValueError("Empty manifest")
            next_url=urllib.parse.urljoin(url,entries[0])
            if any(line.startswith("#EXT-X-STREAM-INF") for line in lines):
                body,url=load(next_url);continue
            segment,_=load(next_url,2048)
            if not segment:raise ValueError("Empty media segment")
            result["ok"]=True;result["reason"]="HLS playlist and media segment reachable";break
        if not result["ok"]:raise ValueError("Playlist nesting limit")
    except Exception as error:
        result["reason"]=type(error).__name__+": "+str(error)[:140]
    return result

def main():
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        results=list(pool.map(probe,[c for c in catalog if c.get("stream")]))
    by_id={r["id"]:r for r in results}
    for channel in catalog:
        if channel.get("stream") and not by_id[channel["id"]]["ok"]:
            channel["stream"]=""
    path.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    report={"checked_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"note":"Availability from GitHub runner region only. Playback and third-party permissions are separate.","channels":len(catalog),"in_app":sum(bool(c["stream"]) for c in catalog),"probes":results}
    (root/"stream-report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    for item in results:print(item["id"],"OK" if item["ok"] else "OFFICIAL SITE",item["reason"])
    print("In-app streams:",report["in_app"],"Directory channels:",len(catalog))

if __name__=="__main__":main()
