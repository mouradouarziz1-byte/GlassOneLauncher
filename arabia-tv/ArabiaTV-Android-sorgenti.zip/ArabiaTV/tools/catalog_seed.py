#!/usr/bin/env python3
"""Editorial directory: official broadcaster pages, never restreaming proxies."""
import json
from pathlib import Path

root=Path(__file__).resolve().parents[1]
channels=[]
def add(id,name,arabic,country,category,official,stream=""):
    channels.append(dict(id=id,name=name,arabic=arabic,country=country,category=category,official=official,stream=stream))

for id,name,ar,path,kind in [
    ("aoula","Al Aoula","الأولى","al-aoula","General"),
    ("arryadia","Arryadia","الرياضية","arryadia","Sports"),
    ("thaqafia","Athaqafia","الثقافية","athaqafia","Culture"),
    ("maghribia","Al Maghribia","المغربية","almaghribia","General"),
    ("assadissa","Assadissa","السادسة","assadissa","Religion"),
    ("tamazight","Tamazight","تمازيغت","tamazight","Culture"),
    ("laayoune","Laayoune TV","العيون","laayoune","General"),
    ("aflam","Aflam TV","أفلام تي في","aflam-tv","General")]:
    add(id,name,ar,"MA",kind,"https://snrtlive.ma/ar/"+path)
add("2m","2M","دوزيم","MA","General","https://2m.ma/")
add("medi1","Medi 1 TV","ميدي 1 تي في","MA","News","https://www.medi1tv.com/fr/live","https://cdn.live.easybroadcast.io/abr_corp/83_medi1tv-arabic_g90v4ec/playlist.m3u8")
for id,name,ar in [("entv","ENTV","الأرضية الجزائرية"),("canalalgerie","Canal Algérie","كنال ألجيري"),("algerie3","Algérie 3","الجزائرية الثالثة")]:
    add(id,name,ar,"DZ","General","https://www.entv.dz/")
add("watania1","Watania 1","الوطنية الأولى","TN","General","https://www.wataniatv.tn/")
add("watania2","Watania 2","الوطنية الثانية","TN","General","https://www.wataniatv.tn/")
add("libyaahrar","Libya Al Ahrar","ليبيا الأحرار","LY","News","https://libyaalahrar.tv/")
add("mauritania","Al Mouritaniya","الموريتانية","MR","General","https://www.tvm.mr/")
for id,name,ar,kind in [("masriya","Al Masriya","المصرية","General"),("nilenews","Nile News","النيل للأخبار","News"),("nilesport","Nile Sport","نايل سبورت","Sports")]:
    add(id,name,ar,"EG",kind,"https://www.maspero.eg/")
add("sudantv","Sudan TV","تلفزيون السودان","SD","General","https://www.sudantv.sd/")
for id,name,ar,kind in [("saudia","Al Saudia","السعودية","General"),("sbc","SBC","إس بي سي","General"),("quran","Quran TV","القرآن الكريم","Religion"),("sunnah","Sunnah TV","السنة النبوية","Religion"),("ekhbariya","Al Ekhbariya","الإخبارية","News")]:
    add(id,name,ar,"SA",kind,"https://www.aloula.sa/live")
for id,name,ar,kind,country in [("mbc1","MBC 1","إم بي سي 1","General","SA"),("mbc2","MBC 2","إم بي سي 2","General","SA"),("mbc3","MBC 3","إم بي سي 3","Kids","SA"),("mbcaction","MBC Action","إم بي سي أكشن","General","SA"),("mbcdrama","MBC Drama","إم بي سي دراما","General","SA"),("mbcmasr","MBC Masr","إم بي سي مصر","General","EG"),("mbc5","MBC 5","إم بي سي 5","General","MA"),("mbciraq","MBC Iraq","إم بي سي العراق","General","IQ")]:
    add(id,name,ar,country,kind,"https://shahid.mbc.net/ar/livestream")
add("arabiya","Al Arabiya","العربية","AE","News","https://live.alarabiya.net/","https://live.alarabiya.net/alarabiapublish/alarabiya.smil/playlist.m3u8")
add("hadath","Al Hadath","الحدث","AE","News","https://www.alhadath.net/","https://live.alarabiya.net/alarabiapublish/alhadath.smil/playlist.m3u8")
add("sky","Sky News Arabia","سكاي نيوز عربية","AE","News","https://www.skynewsarabia.com/livestream-%D8%A7%D9%84%D8%A8%D8%AB-%D8%A7%D9%84%D9%85%D8%A8%D8%A7%D8%B4%D8%B1","https://stream.skynewsarabia.com/hls/sna.m3u8")
add("dubai","Dubai TV","تلفزيون دبي","AE","General","https://www.dubaitv.ae/")
add("abudhabi","Abu Dhabi TV","تلفزيون أبوظبي","AE","General","https://www.abudhabitv.ae/")
add("jazeera","Al Jazeera","الجزيرة","QA","News","https://www.aljazeera.net/video/live","https://live-hls-web-aja.getaj.net/AJA/index.m3u8")
add("mubasher","Al Jazeera Mubasher","الجزيرة مباشر","QA","News","https://www.aljazeera.net/video/live/%D8%A7%D9%84%D8%AC%D8%B2%D9%8A%D8%B1%D8%A9-%D9%85%D8%A8%D8%A7%D8%B4%D8%B1","https://live-hls-web-ajm.getaj.net/AJM/index.m3u8")
add("documentary","Al Jazeera Documentary","الجزيرة الوثائقية","QA","Documentary","https://www.aljazeera.net/video/live","https://live-hls-web-ajd.getaj.net/AJD/index.m3u8")
add("qatartv","Qatar TV","تلفزيون قطر","QA","General","https://www.qtv.qa/")
for id,name,ar,kind in [("kuwait1","Kuwait TV 1","تلفزيون الكويت 1","General"),("kuwaitsport","Kuwait Sports","الكويت الرياضية","Sports")]:
    add(id,name,ar,"KW",kind,"https://media.gov.kw/")
add("bahrain","Bahrain TV","تلفزيون البحرين","BH","General","https://www.mia.gov.bh/")
add("omantv","Oman TV","تلفزيون سلطنة عُمان","OM","General","https://www.omaninfo.om/")
add("iraqia","Al Iraqiya","العراقية","IQ","General","https://imn.iq/")
add("sharqiya","Al Sharqiya","الشرقية","IQ","News","https://www.alsharqiya.com/")
add("jordan","Jordan TV","التلفزيون الأردني","JO","General","https://www.jrtv.gov.jo/")
add("mamlaka","Al Mamlaka","المملكة","JO","News","https://www.almamlakatv.com/live")
add("lbc","LBCI","إل بي سي","LB","General","https://www.lbcgroup.tv/")
add("jadeed","Al Jadeed","الجديد","LB","General","https://www.aljadeed.tv/")
add("mtv","MTV Lebanon","إم تي في لبنان","LB","General","https://www.mtv.com.lb/")
add("palestine","Palestine TV","تلفزيون فلسطين","PS","General","https://www.pbc.ps/")
add("syriatv","Syria TV","تلفزيون سوريا","SY","General","https://www.syria.tv/")
add("yemenshabab","Yemen Shabab","يمن شباب","YE","General","https://yemenshabab.net/")
add("sntv","SNTV Somalia","التلفزيون الصومالي","SO","General","https://sntv.so/")
add("rtd","RTD Djibouti","تلفزيون جيبوتي","DJ","General","https://www.rtd.dj/")
add("ortc","ORTC Comores","تلفزيون جزر القمر","KM","General","https://ortc.km/")
add("france24","France 24 Arabic","فرانس 24 عربي","WORLD","News","https://www.france24.com/ar/live","https://live.france24.com/hls/live/2037222-b/F24_AR_HI_HLS/master_5000.m3u8")
add("dw","DW Arabic","دي دبليو عربية","WORLD","News","https://www.dw.com/ar/","https://dwamdstream107.akamaized.net/hls/live/2017969/dwstream107/index.m3u8")
add("trt","TRT Arabi","تي آر تي عربي","WORLD","News","https://www.trtarabi.com/","https://tv-trtarabi.medya.trt.com.tr/master.m3u8")
add("euronews","Euronews Arabic","يورونيوز عربي","WORLD","News","https://arabic.euronews.com/live")

target=root/"app/src/main/assets/channels.json"
target.parent.mkdir(parents=True,exist_ok=True)
target.write_text(json.dumps(channels,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(f"{len(channels)} channels; {len(set(c['country'] for c in channels))} regions; {sum(bool(c['stream']) for c in channels)} candidate streams")
