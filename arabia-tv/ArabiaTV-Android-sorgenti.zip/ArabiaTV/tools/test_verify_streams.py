import gzip
import unittest
from unittest.mock import patch
import verify_streams

class StreamProbeTest(unittest.TestCase):
    channel={"id":"fixture","name":"Fixture","stream":"https://example.org/master.m3u8"}
    def test_gzipped_master_and_variant_are_decoded(self):
        master=gzip.compress(b"#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=100000\nlow.m3u8\n")
        media=gzip.compress(b"#EXTM3U\n#EXTINF:5,\npart.ts\n")
        with patch.object(verify_streams,"load",side_effect=[(master,"https://example.org/master.m3u8"),(media,"https://example.org/low.m3u8"),(b"video bytes","https://example.org/part.ts")]):
            self.assertTrue(verify_streams.probe(self.channel)["ok"])
    def test_encrypted_manifests_stay_on_official_service(self):
        with patch.object(verify_streams,"load",return_value=(b'#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="key"\nsegment.ts',self.channel["stream"])) as fetch:
            self.assertFalse(verify_streams.probe(self.channel)["ok"])
            self.assertEqual(fetch.call_count,1)
    def test_html_is_not_a_live_manifest(self):
        with patch.object(verify_streams,"load",return_value=(b"<html>Unavailable</html>",self.channel["stream"])):
            self.assertFalse(verify_streams.probe(self.channel)["ok"])
    def test_empty_media_is_not_playable(self):
        with patch.object(verify_streams,"load",side_effect=[(b"#EXTM3U\n#EXTINF:5,\npart.ts",self.channel["stream"]),(b"","https://example.org/part.ts")]):
            self.assertFalse(verify_streams.probe(self.channel)["ok"])
    def test_insecure_url_is_rejected_before_network(self):
        with self.assertRaises(ValueError):verify_streams.load("http://example.org/live.m3u8")

if __name__=="__main__":unittest.main()
