# Arabia TV + Radio 1.1.0

Radio Maroc Android Auto v2.2 è integrata mediante i suoi sorgenti originali dal ramo `radio-maroc-android-auto-v2.2`, commit `e2847c6cf2e9c65fe5e9e6a4fe24cbbe70212238`.

La sezione Radio si apre dalla home TV. Mantiene il catalogo originale di 22 stazioni, preferiti/recenti radio, categorie e ricerca, fallback degli stream, risparmio dati, sleep timer, sveglia con permesso Android richiesto all'utente, MediaLibraryService per ascolto in background e Android Auto. Le interfacce e i dati TV e radio restano distinti all'interno dello stesso APK. L'interfaccia radio mantiene le etichette originali italiane; quella TV supporta italiano/arabo.

Il nuovo applicationId `it.mourad.arabiatvradio` permette l'installazione accanto alle precedenti Arabia TV e Radio Maroc. I dati privati delle app precedenti non sono trasferiti automaticamente. Il nome nel launcher è Arabia TV + Radio.

## Trasmissione Samsung

Nel lettore TV e nella pagina Radio è presente Trasmetti su TV Samsung / DLNA. La home offre anche l'accesso alle opzioni e alla guida.

1. Accendere la TV e collegare TV e telefono alla stessa rete Wi-Fi.
2. Aprire una diretta In app o scegliere una stazione radio.
3. Premere Trasmetti, quindi Cerca TV sulla rete (DLNA).
4. Scegliere il televisore individuato. Il client invia SetAVTransportURI e Play; solo dopo l'accettazione dei comandi sospende il lettore locale.
5. Verificare immagine/audio sulla TV. I comandi Pausa, Riprendi e Ferma TV sono disponibili nel dialogo di controllo. Il menu permette di riaprire il controllo dell'ultima TV nella sessione corrente.

La TV scarica direttamente il flusso: non vengono creati proxy, transcodifiche o bypass DRM. Una risposta positiva ai comandi non garantisce che il TV sappia decodificare quel formato. La disponibilità dipende da modello, firmware, rete, codec e supporto UPnP AVTransport. Non è stata eseguita una prova su una TV Samsung fisica.

Come alternativa, Smart View / proietta schermo prova ad aprire le impostazioni Cast di Android e fornisce le istruzioni per Smart View nel pannello rapido Galaxy. Non connette automaticamente il televisore, né installa un'app Tizen. I canali Sito ufficiale restano gestiti dal servizio esterno.

Le connessioni HTTP locali sono necessarie per il protocollo DLNA. Il traffico non cifrato è abilitato anche per preservare i fallback HTTP della radio originale; l'importatore playlist TV continua ad accettare solo HTTPS. La ricerca DLNA controlla indirizzi locali e rifiuta descrizioni XML con DTD/entità esterne e URL di controllo su host diversi dall'emittente della descrizione.

## Verifica

Il workflow esegue compilazione, Android Lint, test del catalogo e del parser, test HLS, test SOAP con un renderer simulato, controlli delle schermate radio/cast e test di riproduzione TV su emulatore. Consultare l'esito della run per i risultati effettivi. I test del protocollo non equivalgono a una prova sul televisore dell'utente. Android Auto richiede un'autoradio compatibile e può richiedere la configurazione di sviluppo per un APK installato manualmente.
